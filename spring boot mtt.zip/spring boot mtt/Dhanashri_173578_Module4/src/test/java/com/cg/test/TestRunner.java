package com.cg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * Test class for coaching class enquiry form validations
 * 
 * @author Dhanashri Sanase
 */
@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources" }, glue = { "com.cg.step" }, tags = { "@execute" })
public class TestRunner {

}
