
package com.cg.control;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.EmployeeEntity;
import com.cg.service.IEmployeeService;

/**
 * RestController for employee management system application.
 * @author Dhanashri Sanase
 *
 */

@RestController
public class EmployeeController {

	
	//Autowiring IEmployeeService
	@Autowired
	IEmployeeService service;

	
	//adding employee records
	@PostMapping(name="/addEmployee")
	public String addEmployee(@RequestParam("name") String name, @RequestParam("designation") String designation,
			@RequestParam("salary") int salary, @RequestParam("deptName") String deptName) {

		return service.addEmployee(name, designation, salary, deptName);
	}

	
	//updating employee records
	@PutMapping(path="/updateEmployee/{employeeId}", consumes= "application/json")
	public String updateEmployee(@PathVariable("employeeId") int employeeId, @RequestBody EmployeeEntity employee) {
		return service.updateEmployee(employee, employeeId);
	}

	
	//deleting employee record
	@DeleteMapping("/deleteEmployee/{employeeId}")
	public String deleteEmployee(@PathVariable("employeeId") int employeeId) {
		return service.deleteEmployee(employeeId);
	}

	
	//fetching all employees records
	@GetMapping("/employees")
	public List<EmployeeEntity> getAllEmployees() {
		return service.getAllEmployees();
	}

	
	
	@GetMapping(path = "/getById", produces = "application/json")
	public ResponseEntity<EmployeeEntity> getEmployee(@RequestParam("employeeId") int employeeId) {
		try {
			EmployeeEntity emp = service.getEmployee(employeeId);
			return new ResponseEntity<EmployeeEntity>(emp, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	
	
	@GetMapping(path = "/employees/{departmentName}", produces = "application/json")
	public List<EmployeeEntity> findByDepartmentName(@PathVariable("departmentName") String departmentName) {
		return service.findByDepartmentName(departmentName);
	}

}
