package com.cg.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.EmployeeEntity;
import com.cg.repo.IEmployeeRepo;

/**
 * Service class for employee management system application
 * @author Dhanashri Sanase
 *
 */

@Service("service")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	//autowiring IEmployeeRepo
	@Autowired
	IEmployeeRepo repo;
	
	//adding employee
	@Override
	public String addEmployee(String name, String designation, int salary, String deptName) {
		EmployeeEntity employee=new EmployeeEntity();
		employee.setName(name);
		employee.setDesignation(designation);
		employee.setSalary(salary);
		employee.setDeptName(deptName);
		repo.save(employee);
		return "Employee added successfully.";
	}

	//updating employee records
	@Override
	public String updateEmployee(EmployeeEntity employee, int id) {
		employee.setEmpId(id);
		repo.save(employee);
		return "Employee updated successfully";
	}

	
	//deleting employee records
	@Override
	public String deleteEmployee(int employeeId) {
		repo.deleteById(employeeId);
		return "Employee record deleted successfully.";
	}

	//listing of all employee records
	@Override
	public List<EmployeeEntity> getAllEmployees() {
		return (List<EmployeeEntity>) repo.findAll();
	}

	//getting employee records
	@Override
	public EmployeeEntity getEmployee(int employeeId) {
		try {
			return repo.findById(employeeId).get();
			
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No employee found with ID "+employeeId);
		}
	}


	//finding employee records by their Department Name
	@Override
	public List<EmployeeEntity> findByDepartmentName(String departmentName) {
		return repo.findAllBydeptName(departmentName);
	}

}
