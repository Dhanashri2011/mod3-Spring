/**
 * 
 */
package com.cg.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.EmployeeEntity;

/**
 * Service inteface for employee management system application
 * @author Dhanashri Sanase
 *
 */
public interface IEmployeeService {

	//Service methods for creating , updating , deleting , listing and finding employee records.
	
	
	public String addEmployee(String name, String designation, int salary, String deptName);

	public String updateEmployee(EmployeeEntity employee, int id);

	public String deleteEmployee(int employeeId);

	public List<EmployeeEntity> getAllEmployees();

	public EmployeeEntity getEmployee(int employeeId);

	public List<EmployeeEntity> findByDepartmentName(String departmentName);

}
