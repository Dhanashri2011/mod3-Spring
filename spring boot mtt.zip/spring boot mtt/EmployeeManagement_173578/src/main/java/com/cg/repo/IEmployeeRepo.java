/**
 * 
 */
package com.cg.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.EmployeeEntity;

/**
 * Repo interface for employee management system application
 * @author Dhanashri Sanase
 */
public interface IEmployeeRepo extends CrudRepository<EmployeeEntity, Integer> {
	
	List<EmployeeEntity> findAllBydeptName(String departmentName); 
}
