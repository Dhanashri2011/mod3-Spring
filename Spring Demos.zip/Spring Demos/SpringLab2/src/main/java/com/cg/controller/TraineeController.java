package com.cg.controller;

public class TraineeController {



}
