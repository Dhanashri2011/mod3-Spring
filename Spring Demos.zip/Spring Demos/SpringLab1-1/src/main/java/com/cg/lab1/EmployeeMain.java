package com.cg.lab1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class EmployeeMain {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new ClassPathXmlApplicationContext("Employee.xml");
		Employee emp = (Employee) ctx.getBean("emp");
		System.out.println("Employee details : ");
		System.out.println("Employee Id 	: "+emp.getEmpId());
		System.out.println("Employee name   : "+emp.getName());
		System.out.println("Employee salary : "+emp.getSalary());
		System.out.println("Employee BU 	: "+emp.getBU());
		System.out.println("Employee Age	: "+emp.getAge());
	}
}
