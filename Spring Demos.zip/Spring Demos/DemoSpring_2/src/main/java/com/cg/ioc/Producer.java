
package com.cg.ioc;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Producer implements ApplicationContextAware {//implementing ApplicationContextAware because we want its reference
	//ApplicationContext is a container which refers beans
	
	private ApplicationContext ctx;

	public void process(String type, String to, String msg) {
		Sender sender = (Sender) ctx.getBean(type);
		sender.send(to, msg);
	}

	//setter injection
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.ctx = applicationContext;
	}

}
