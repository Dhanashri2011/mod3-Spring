package com.cg.ioc;

public class Client {

	
	//singleton class to instantiate Client only once 
	private static Client client;

	public static Client getClient() {
		if(client==null)
			client=new Client();
		
		return client;
	}
}