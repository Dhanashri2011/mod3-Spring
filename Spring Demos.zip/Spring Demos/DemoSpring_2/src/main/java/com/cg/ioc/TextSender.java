package com.cg.ioc;

public class TextSender implements Sender {
	public TextSender() {
		System.out.println("Text sender is ready");
	}

	public void send(String to, String msg) {
		System.out.println("Text : " + msg + " sent to " + to);
	}

}
