package com.cg.test;

import org.junit.Test;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMyLife {

	@Test
	public void testing() {
		//ConfigurableApplicationContext ctx= new ClassPathXmlApplicationContext("sender.xml");
		
		ConfigurableApplicationContext ctx= new ClassPathXmlApplicationContext("annotated.xml");                               
		ctx.close();//destroy method gets called
	}
}
