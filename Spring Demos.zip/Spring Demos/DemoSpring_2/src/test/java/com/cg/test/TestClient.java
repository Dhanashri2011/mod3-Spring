package com.cg.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Client;



public class TestClient {

	@Test
	public void testClient() {
		//ApplicationContext ctx= new ClassPathXmlApplicationContext("hello.xml"); 

		ApplicationContext ctx= new ClassPathXmlApplicationContext("annotated.xml");
			Client c1= (Client) ctx.getBean(Client.class);
			Client c2= (Client) ctx.getBean(Client.class);
			
		assertEquals(c1, c2);
	}
}
