package com.cg.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Hello;

public class TestHello {
	
	@Test
	public void testGetObject() {
		//ApplicationContext ctx = new ClassPathXmlApplicationContext("hello.xml");
		ApplicationContext ctx= new ClassPathXmlApplicationContext("annotated.xml");
		Hello h = (Hello) ctx.getBean("hi");
		assertNotNull("NullObject", h);
		System.out.println(h.getGreeting());
	}
}
