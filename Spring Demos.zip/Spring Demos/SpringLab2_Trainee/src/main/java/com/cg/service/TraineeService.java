package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Trainee;
import com.cg.repo.TraineeRepo;

@Service
@Transactional
public class TraineeService implements ITraineeService{
	
	@Autowired
	TraineeRepo repo;

	@Override
	public void addDetails(Trainee trainee) {
		repo.save(trainee);
	}

	@Override
	public void deleteDetails(Trainee trainee) {
		repo.delete(trainee);
	}

	@Override
	public void modifyDetails(Trainee trainee) {
		repo.save(trainee);
		
	}

	@Override
	public Trainee retrieveTrainee(int id) {
		return repo.findById(id).get();
		
	}

	@Override
	public List<Trainee> retrieveAllTrainees() {
		return (List<Trainee>) repo.findAll();
	}
	
	
}
