package com.test.spring.boot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Login;

@RestController
@RequestMapping(value = "user")
public class TraineeController {
	
	 @RequestMapping("/")
	    public String home(){
	        return "Hello World!";
	    }
	
	@RequestMapping(value = "showLogin")
	public String prepareLogin(Model model) {
		System.out.println("In prepareLogin() method");
		//model.addAttribute("login", new Login());
		return "login";
	}
	

	@RequestMapping(value = "checkLogin")
	public String checkLogin(@RequestParam("userName") String uname, @RequestParam("password") String pwd, Login login,
			Model model) {
		// Logic to validate userName and password against database
		if (uname.equals("dhanashri") && pwd.equals("admin")) {
			model.addAttribute("login", login);
			return "loginSuccess";
		} else {
			String invalid = "invalid details, enter valid details";
			model.addAttribute("invalid", invalid);
			return "login";
		}
	}

}
