package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Employee;

public class DaoImpl implements Dao{

	List<Employee> emps= new ArrayList<Employee>();
	ApplicationContext ctx = new ClassPathXmlApplicationContext("emps.xml");
	Employee emp= (Employee) ctx.getBean("emp");
	Employee emp2= (Employee) ctx.getBean("emp2");
	Employee emp5=(Employee) ctx.getBean("name");
	
	@Override
	public void addAll() {
		emps.add(emp);
		emps.add(emp2);

	}
	
	@Override
	public Employee findEmp(int id) {
		for(Employee e : emps) {
			if(e.getEmpId()==id)
				return e;
			else 
				return null;
		}
		return null;
	}

	
}
