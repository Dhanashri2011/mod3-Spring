package com.cg.ctlr;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Scope("session")
@Controller
@RequestMapping(value = "user")
public class UserController {
	ArrayList<String> cityList = new ArrayList<String>();
	ArrayList<String> skillList = new ArrayList<String>();
	
	@RequestMapping(value = "showLogin")
	public String prepareLogin(Model model) {
		System.out.println("In prepareLogin() method");
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(@RequestParam("userName") String uname, @RequestParam("password") String pwd, Login login,
			Model model) {
		// Logic to validate userName and password against database
		if (uname.equals("dhanashri") && pwd.equals("admin")) {
			model.addAttribute("login", login);
			return "loginSuccess";
		} else {
			String invalid = "invalid details, enter valid details";
			model.addAttribute("invalid", invalid);
			return "login";
		}
	}

	@RequestMapping(value = "showRegister")
	public String prepareRegister(Model model) {

		
		cityList.add("Mumbai");
		cityList.add("Bangalore");
		cityList.add("Chennai");
		cityList.add("Delhi");


		skillList.add("Java");
		skillList.add("Struts");
		skillList.add("Spring");
		skillList.add("Hibernate");

		model.addAttribute("cityList", cityList);
		model.addAttribute("skillList", skillList);
		model.addAttribute("user", new User());
		return "register";
	}

	@RequestMapping(value = "checkRegister")
	public String checkRegister(@ModelAttribute("user") @Valid User user, BindingResult result, Model model)
	{
		
		if (result.hasErrors()) {
			System.out.println("Error");

			model.addAttribute("cityList", cityList);

			model.addAttribute("skillList", skillList);

			return "register";
		} else {

			model.addAttribute("user", user);
			System.out.println("Valid  dd");
			return "registerSuccess";
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logOut(Model model) {

		String logoutmsg = "You have successfully logout";
		model.addAttribute("logoutmsg", logoutmsg);
		return "login";
	}

}
