package com.cg.sevice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.ProductEntity;
import com.cg.repo.Repo;



@SpringBootApplication
@EntityScan("com.cg.entity")
public class Service implements IService{
	
	@Autowired
	private Repo repo;

	@Override
	@Transactional
	public ProductEntity get(int id) {
		ProductEntity p= repo.findById(id).get();
		return p;
	}

	@Override
	@Transactional
	public List<ProductEntity> getAll() {
		return (List<ProductEntity>) repo.findAll();
	}

	@Override
	@Transactional
	public void saveProduct(ProductEntity p) {
		repo.save(p);
	}
	
	@Override
	@Transactional
	public String delete(int id) {
		repo.deleteById(id);
		return "Product deleted";
	}

	@Override
	@Transactional
	public void updateProduct(ProductEntity p) {
		repo.save(p);
	}
	
	
	
}
