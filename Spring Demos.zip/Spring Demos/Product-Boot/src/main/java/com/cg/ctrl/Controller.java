package com.cg.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.ProductEntity;
import com.cg.sevice.Service;

@RestController
public class Controller {

	@Autowired
	public Service service;

	@GetMapping("/getProducts")
	public List<ProductEntity> getproducts() {
		return service.getAll();
	}

	@PostMapping("/saveProduct")
	public String saveProduct(@RequestParam("name") String name, @RequestParam("price") int price) {
		ProductEntity p = new ProductEntity();
		p.setName(name);
		p.setPrice(price);
		service.saveProduct(p);
		return "Item saved successfully";
	}

	@GetMapping(name = "/product", produces = "application/json")
	public ProductEntity getProduct(@RequestParam("id") int id) {
		ProductEntity p = service.get(id);
		return p;
	}

	@DeleteMapping(path = "/deleteproduct")
	public String delete(@RequestParam("id") int id) {
		return service.delete(id);

	}

	@PutMapping(path = "/updateproduct")
	public String updateProduct(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("price") int price) {
		ProductEntity prod = service.get(id);
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		service.updateProduct(prod);
		return "product is updated";
	}
}
