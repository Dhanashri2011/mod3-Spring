package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.ProductEntity;

public interface Repo extends CrudRepository<ProductEntity, Integer> {

}
