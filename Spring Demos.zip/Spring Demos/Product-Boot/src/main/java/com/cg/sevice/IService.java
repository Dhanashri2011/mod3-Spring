package com.cg.sevice;

import java.util.List;
import java.util.Optional;

import com.cg.entity.ProductEntity;


public interface IService {
	ProductEntity get(int id);
	List<ProductEntity> getAll();
	void saveProduct(ProductEntity p);
	public String delete(int id);
	public void updateProduct(ProductEntity p);
}
