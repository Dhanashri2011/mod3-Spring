package com.cg.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.AlbumEntity;
import com.cg.repo.AlbumRepo;

//@Service("service")
@SpringBootApplication
@EntityScan("com.cg.entity")
@Transactional
public class AlbumServiceImpl implements AlbumService {

	
	@Autowired
	AlbumRepo repo;

	@Override
	public void saveAlbum(AlbumEntity album) {
		repo.save(album);
	}

	@Override
	public AlbumEntity getAlbum(int albumId) throws NoSuchElementException {
		try {
			return repo.findById(albumId).get();
			
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No element found");
		}
	}

	
	
	@Override
	public void updateAlbum(AlbumEntity album) {
		repo.save(album);
	}

	@Override
	public void deleteAlbum(int id) {
		repo.deleteById(id);
	}

	@Override
	public List<AlbumEntity> getAll() {
		return (List<AlbumEntity>) repo.findAll();
		}
	

	@Override
	public void updateAlbumID(AlbumEntity a,int id){
		a.setId(id);
		repo.save(a);
	}

	@Override
	public AlbumEntity findByartist(String artist) {
		return repo.findByartist(artist);
	}
}
