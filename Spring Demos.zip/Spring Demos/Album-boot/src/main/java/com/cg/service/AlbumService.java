package com.cg.service;

import java.util.List;
import java.util.NoSuchElementException;

import com.cg.entity.AlbumEntity;

public interface AlbumService {

	
	public void saveAlbum(AlbumEntity album); 
	public AlbumEntity getAlbum(int albumId) throws NoSuchElementException;
	public void updateAlbum(AlbumEntity album);
	public void deleteAlbum(int id);
	public List<AlbumEntity> getAll();
	public void updateAlbumID(AlbumEntity a,int id);
	public AlbumEntity findByartist(String artist); 
}
