package com.cg.ctrl;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.AlbumEntity;
import com.cg.service.AlbumService;

@RestController
public class AlbumController {

	@Autowired
	AlbumService service;

	
//	@ResponseStatus(value=HttpStatus.NOT_FOUND,
//			reason="Album with this id not present")
//			@ExceptionHandler({Exception.class})
//			public void handleException() {
//			}

	@GetMapping(path="/getalbum/{id}", produces="application/json")
	public ResponseEntity<AlbumEntity> getMYAlbum(@PathVariable("id") int id) {
	try {
		AlbumEntity a= service.getAlbum(id);
	return new ResponseEntity<AlbumEntity>(a, HttpStatus.OK);
	}catch(NoSuchElementException e) {
	return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	}

	@GetMapping(path="/getByName/{artist}", produces="application/json")
	public AlbumEntity findByartist(@PathVariable("artist") String artist) {
		return service.findByartist(artist);
	}
	
	@PostMapping("/save")
	public void saveAlbum(@RequestParam("title") String title,
			@RequestParam("artist") String artist, @RequestParam("price") int price) {
		
		AlbumEntity album=new AlbumEntity(title,artist,price);
		service.saveAlbum(album);
		System.out.println("Album Saved Successfully");
	}
	
	
	
//	@GetMapping(name="/get", produces = "application/json")
//	public AlbumEntity getAlbum(@RequestParam("id") int albumId) throws NoSuchElementException {
//		try {
//			return service.getAlbum(albumId);
//		} catch (NoSuchElementException e) {
//			throw new NoSuchElementException("Album id not found");
//		}
//		
//	}
	
	
	
	@PutMapping("/update")
	public String updateAlbum(@RequestParam("id") int id,@RequestParam("title") String title,
			@RequestParam("artist") String artist, @RequestParam("price") int price) {
		AlbumEntity album=new AlbumEntity(title,artist,price);
		album.setId(id);
		service.updateAlbum(album);
		return "Album updates successfully";
	}
	
	
	@PutMapping(path="/updateID/{id}", consumes= "application/json")
	public String updateAlbumID(@PathVariable("id") int id,@RequestBody AlbumEntity a) {
		
		service.updateAlbumID(a,id);
		return "Album ID updates successfully";
	}
	
	
	@DeleteMapping("/delete")
	public String deleteAlbum(@RequestParam("id") int id) {
		service.deleteAlbum(id);
		return "Album deleted successfully";
	}

	@GetMapping("/getAlbums")
	public List<AlbumEntity> getAll() {
		return service.getAll();
		}

}
