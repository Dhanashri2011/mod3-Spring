package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Albums_table")
public class AlbumEntity {
	
	@Id
	@GeneratedValue
	int id;
	String title;
	String artist;
	int price;
	
	//constructor
	public AlbumEntity() {
		// TODO Auto-generated constructor stub
	}
	
	//constructor using fields
	public AlbumEntity(String title, String artist, int price) {
		super();
		this.title = title;
		this.artist = artist;
		this.price = price;
	}
	
	
	//getters and setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
	
}
