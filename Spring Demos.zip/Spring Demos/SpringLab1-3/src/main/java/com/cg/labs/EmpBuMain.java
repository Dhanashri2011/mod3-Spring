package com.cg.labs;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpBuMain {
	
	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("emps.xml");
		SBU bu= (SBU) context.getBean("bu");
		Employee e=(Employee) context.getBean("emp1");
		Employee e2=(Employee) context.getBean("emp2");
		List<Employee> em=new ArrayList<Employee>();
		em.add(e);
		em.add(e2);
		bu.setEmps(em);
		
		System.out.println(bu);
	}
}
