package com.cg.lab2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class SbuDao {
	
	public  Employee getSbuDetails() {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("sbu.xml");
		
		Employee emp = (Employee) ctx.getBean("emp");
		
		return emp;
	}
	
	
}
