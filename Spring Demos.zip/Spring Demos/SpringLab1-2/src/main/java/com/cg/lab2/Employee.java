package com.cg.lab2;

public class Employee {
	
	int empId;
	String name;
	double salary;
	SBU BU;
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public SBU getBU() {
		return BU;
	}
	public void setBU(SBU bU) {
		BU = bU;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", salary=" + salary + ",\n SBU details=" + BU + "]";
	}
	
	
	
}
