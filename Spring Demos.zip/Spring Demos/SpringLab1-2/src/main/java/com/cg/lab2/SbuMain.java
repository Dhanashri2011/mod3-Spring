package com.cg.lab2;

public class SbuMain {
	public static void main(String[] args) {
		
		SbuDao dao = new SbuDao();
		
		Employee emp = dao.getSbuDetails();
		
		System.out.println("Employee Details are as follows : ");
		System.out.println(emp);
	}
}
